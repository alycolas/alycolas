## Note ##

If you use the latest Awesome built from git since 09.03.2012 then you already have Menubar. Press Modkey-P to see it.

## What ##

Dmenu-like menu for Awesome WM.

Parses folders like /usr/share/applications for .desktop files.
Shows icons for categories and applications.
Completely keyboard-controllable.

## More ##

See http://awesome.naquadah.org/wiki/Menubar . Installation guide, screenshots and detailed description can be also found there.

